function [P_xzt]=diffus_rain(z,t,h,dh,D,P)
%==========================================================================
% Computes the pore pressure diffusion induced by the change in water table
% height. The diffusion is determined with an impulse response function
% computed from [1].
% For a water table rise, hydrostatic pore pressure is applied immediately
% between the old and new water table height, and the pressure diffusion is
% applied downwards from the last water table position.
% For water table drop, all pore pressure above the water table is set to 0
% and the loss of hydrostatic pressure is diffused downwards from the new
% water table position
%
% INPUTS : z slope-normal depth [m]
%          t time [s]
%          h slope-normal water table depth [m]
%          dh slope-normal water table depth variations [m]
%          D hydraulic diffusivity [m�/s]
%          P pressure changes at the water surface [kPa]
% OUTPUTS : P_xzt(x,z,t) pore pressure due to surface pressure diffusion
%
% [1]: Carslaw, H. S., & Jaeger, J. C. (1959). Conduction of heat in solids (second edi).
% Lucas PELASCINI, sept 2020
%==========================================================================

dz=z(2)-z(1);
C=erfc(z'./sqrt(4*D.*t));% response to a heaviside
C(isnan(C))=0;
P_xzt=zeros(length(h),length(z),length(t));% Dynamic pore pressure
z_i=max(min(1+fix((h+dh)/dz),length(z)),1);% water table depth=z(z_i)
dP=zeros(length(h),length(z),length(t));% Water Surface Pressure change

for xx=1:length(h)
    for tt=1:length(t)-1
        dP(xx,z_i(xx,tt),tt+1)=P(xx,tt);
    end
    temp=conv2(squeeze(dP(xx,:,:)),C);
    temp=temp(1:length(z),1:length(t));
    P_xzt(xx,:,:)=squeeze(P_xzt(xx,:,:))+temp;

    for tt=1:length(t)% set to 0 above water table
        P_xzt(xx,1:z_i(xx,tt),tt)=0;
        % WARNING: Does not reset the pressure if the water table rises
        % again, effects of ancient pressure variations will remain
    end
end
P_xzt(P_xzt<0)=0;
end