function [sigma_n,u,tau]=stress(z,t,h,Rho,Alpha)
%==========================================================================
% Computes normal and shear stress in the slope
%
% INPUTS : z vertical depth vector [m]
%          t time [s]
%          h depth of water table [m]
%          Rho unit weight of water & saturated material [kN/m^3 or kPa/m]
%          Alpha angle of the slope [degree]
% OUTPUTS : sigma_n normal stress [kPa]
%           u pore pressure from static water table [kPa]
%           tau shear stress [kPa]
% Lucas PELASCINI, oct 2019
%==========================================================================
w=z*Rho.sat;
u=repmat(max((z-h),0)*Rho.w,1,1,length(t));% pore pressure due to static height of water [kPa]

tau=w*cosd(Alpha)*sind(Alpha);% cos to account the augmentation of surface due to slope, and sin to take the shear stress
sigma_n=w*cosd(Alpha)*cosd(Alpha);% cos� to account the augmentation of surface due to slope, and to take the normal stress
end