function [P_xzt]=diffus_atmo(z,t,h,dh,D,Pa)
%==========================================================================
% Computes the pore pressure diffusion induced by the change in atmospheric
% pressure. The diffusion is determined with an impulse response function
% computed from [1].
% The diffusion starts from the water table depth, which is ajusted every
% timestep to correspond to the recharge.
% INPUTS : z slope-normal depth
%          t time [s]
%          h(x) slope-normal water table depth [m]
%          dh(x,t) slope-normal water table depth variations [m]
%          D hydraulic diffusivity [m�/s]
%          Pa(t) pressure at the water surface [kPa]
%
% OUTPUTS : P_xzt(x,z,t) pore pressure due to surface pressure diffusion
%
% [1]: Carslaw, H. S., & Jaeger, J. C. (1959). Conduction of heat in solids (second edi).
% Lucas PELASCINI, sept 2020
%==========================================================================

dz=z(2)-z(1);
C=erfc(z'./sqrt(4*D.*t));% response to a heaviside (i.e. change in pressure)
C(isnan(C))=0;
C=C-1;% to model the instant pressure change in the skeleton (ie Pa in Schulz)
z_i=max(min(1+fix((h+dh)/dz),length(z)),1);% water table depth=z(z_i)

dPa=diff(Pa);% atmospheric pressure variation
dP=zeros(length(h),length(z),length(t));% Pressure change
P_xzt=zeros(length(h),length(z),length(t));% Dynamic pore pressure

for xx=1:length(h)
    for tt=1:length(t)-1
        dP(xx,z_i(xx,tt),tt+1)=dPa(tt);
    end
    temp=conv2(squeeze(dP(xx,:,:)),C);
    temp=temp(1:length(z),1:length(t));
    P_xzt(xx,:,:)=squeeze(P_xzt(xx,:,:))+temp;

    for tt=1:length(t)% set to 0 above water table
        P_xzt(xx,1:z_i(xx,tt),tt)=0;
        % WARNING: Does not reset the pressure if the water table rises
        % again, effects of ancient pressure variations will remain
    end
end
end
