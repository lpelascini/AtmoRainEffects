function [h,dh]=Townley_num_IR(x,r,T,filename)
%==========================================================================
% Computes the static and dynamic head of the water table in function of
% the recharge using a numerical impulse response function numerically
% computed from the periodic solution in:
% "The response of aquifers to periodic forcing" Lloyd R. Townley (1995)
% x=0 => Dirichlet h=h0
% x=L => Neumann dh/dx=0 (no flow)
%
% INPUTS :    x [m]: horizontal position
%             r(t) [m/s]: recharge
%             T [m�/s]: transmissivity
%             filename: file containing the Impulse Response function
%
% OUTPUTS :   h(x) [m]: static head
%             dh(x,t)[m]: dynamic head
%==========================================================================

L=x(end);% [m]
% r_static=mean(r);
% r_static=r(1);
r_static=0;
h=r_static/T*(L*x-.5*x.^2);% static component [m]
load(filename);
if sum(size(IR)~=size(x'*r))% making sure the size is correct
    IR=IR(1:length(x),1:length(r));
end

dh=conv2(r-r_static,IR);
dh=dh(:,1:length(r));% dynamic component [m]

end



