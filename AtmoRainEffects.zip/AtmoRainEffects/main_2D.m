% =========================================================================
% This code is a two-dimentionnal approximation of the effects triggering 
% landslides. Rainfall infiltration [1] and atmospheric pressure variations
% [2] are considered in a finite hillslope model.
% 
% [1]: Iverson, R. M. (2000). Landslide triggering by rain infiltration. Water resources research, 36(7), 1897-1910.
% [2]: Schulz, W. H., Kean, J. W., & Wang, G. (2009). Landslide movement in southwest Colorado triggered by atmospheric tides. Nature Geoscience, 2(12), 863-866.
% 
% Lucas PELASCINI
% Oct 2019
% =========================================================================
tic;
addpath Data% datafile with typhoon timeseries & impulse response fuctions
addpath functions% functions needed

%% slope propreties
alpha=25;% angle of the slope [degree]
x_max=500; dx=50; x=(0:dx:x_max);% horizontal distance to river [m]
z_max=round(x_max*tand(alpha)+10,-1); dz=1; z=(0:dz:z_max);% vertical local depth [m]
topo=x*tand(alpha);% topography of the slope [m]
width=500;% hillslope width [m]

c=20;% cohesion [kN/m� or kPa]
Phy=30;% angle of friction [degree]
D=1e-2;% Hydraulic diffusivity m�/s]
Kz=1e-6;% hydraulic conductivity [m/s]
S=1e-2;% Storage []

Rho.sat=20;% unit weight of saturated material [kN/m^3 or kPa/m]
Rho.w=9.8;% unit weight of water [kN/m^3 or kPa/m]

if D==1e-2% numerical response function
    resp_fn='IR_D1e-2_S1e-2_dt3600_dx50.mat';
elseif D==1e-4
    resp_fn='IR_D1e-4_S1e-2_dt3600_dx50.mat';
elseif D==1e-6
    resp_fn='IR_D1e-6_S1e-2_dt3600_dx50.mat';
end
%% DATA
% real data || Typhoons and mean typhoon || -------------------------------
%{
% filename='Typhoon_Masta_05.mat';% high rainfall response
% filename='Typhoon_Krosa_07.mat';% high atmospheric response
% filename='Typhoon_Morakot_09.mat';% high rainfall response
filename='Typhoon_Synth_mean_data.mat';

load(filename);% data file with a matlab structure:
               %      typhoon.P : atmospheric pressure [kPa]
               %             .R : rainfall [m�/s]
               %             .date : format yyyy-mm-dd HH:MM:SS
               %             .wet : quantity od rainfall during the last 6 months [m]

t=datenum(typhoon.date,'yyyy-mm-dd HH:MM:SS'); t=86400*(t'-t(1));% duration vector [s]
dt=t(2)-t(1);% time sampling [s]
P_atmo=permute(typhoon.P-typhoon.P(1),[1,3,2]);% atmospheric pressure [kPa]
recharge=min(typhoon.R',Kz);% rainfall [m�/s]
initial_h=( typhoon.wet/(6*30*86400) )/(D*S) * (x_max*x - .5*x.^2);% Dupuits-Forchheimer with the last 6 months recharge to have an initial height of water table
%}
% Synth data || Gate function || ------------------------------------------
%%{
dt = 3600;% time sampling [s/element]
t = (0:dt:50*24*3600);% time vector [s]
T_storm = 1*24*3600/dt;% duration of the storm (in Nb of time samples)
t_storm = 1+24*3600/dt;% beginning time of the storm (in Nb of time samples)
recharge=zeros(size(t)); recharge((86400/dt)+1:2*86400/dt)=Kz;
P_atmo = zeros(1,1,length(t)); P_atmo(t_storm:t_storm+T_storm-1) = -1;% atmospheric pressure [kPa]

initial_h=1*1e-9/(D*S) * (x_max*x - .5*x.^2);% Dupuits-Forchheimer with the last 6 months recharge to have an initial height of water table
%}

%% hillslope groundwater flow model
[h,dh]=Townley_num_IR(x,recharge,S*D,resp_fn);
h=h+initial_h;
h=min(h,topo);% suppr water above topography
dh=min(dh,(topo-h)');% suppr water above topography
h=(topo-h)';% vertical depht of water table [m]
dh=-dh;% depth changes of Water Table (dh>0: downward) [m]

%% Pore pressure and stress computation
[sigma_n,u,tau]=stress(z,t,h,Rho,alpha);% values in kPa

dP_rain=diff(-dh,[],2)*Rho.w;% Pressure change due to dh
u_rain=diffus_rain(z/cosd(alpha),t,h/cosd(alpha),dh/cosd(alpha),D,dP_rain);% pressure diffusion: convolution by impulse response function (Carslaw & Jaeger)
u_atmo=diffus_atmo(z/cosd(alpha),t,h/cosd(alpha),dh/cosd(alpha),D,P_atmo);

F=(c+(repmat(sigma_n,length(x),1,length(t))-u)*tand(Phy))./tau;
F_rain=(c+(repmat(sigma_n,length(x),1,length(t))-u-u_rain)*tand(Phy))./tau;
F_atmo=(c+(repmat(sigma_n,length(x),1,length(t))-u-u_atmo)*tand(Phy))./tau;
F_tot=(c+(repmat(sigma_n,length(x),1,length(t))-u-u_rain-u_atmo)*tand(Phy))./tau;
