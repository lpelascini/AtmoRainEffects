This folder contains scripts and data intended to run with MATLAB (tested with R2020b)
Run 'main_2D.m' to perform computaions.
It will need
- the funtions includeed in the 'functions' folder
- an impulse response function (some are provided in the 'Data' folder, but other
  can be computed by 'inversion_impulse_response_fn.m' if needed).
- data: timeseries of rainfall and atmospheric pressure changes (some are provided
  in the 'data' floder, but the user can also directly create a synthetic event in
  the code 'main_2D.m', lines 40 to 70

Results are not saved in any file, it is up to the user to save or print the data.