%==========================================================================
% WARNING: this code is not optimized and takes time to run.
% This code computes the response function to rainfall of water table in a
% hillslope (no flow uphill; head fixed at h=0 downhill). The response
% function is computed numerically, with a ifft so it is not the exact
% solution. Response function has a hight value at low frequencies, so the
% precision of the computed response function depends on the max length of
% time vecor considered.
% The code uses an iterative test in order to find the optimal length to
% get the response function with acceptable error.
% More info about the hydrological model: L.Townley, 1995
% 
% Lucas PELASCINI
% sept 2020
%==========================================================================

clear all;
close all;
tic
%% model properties

i_max=1000;% maximum iteration number

t_max=86400*(1:i_max);% max duration for the computation [s]


L=500;% max length of hillslope
dx=50;
x=(0:dx:L);% vector of hillslope position

D=1e-4;% Hydraulic Diffusivity [m�/s]
S=1e-2;% Storage []

dt=600;% temporal resolution [s]

%% initialization
ii=1;
IR=cell(i_max,1);

nb=t_max/dt+1;

t=0:dt:t_max(1);% time vect [s]

f=(1:floor(nb(1)/2))/t_max(1);% frequency vec [Hz]
w=2*pi.*f;
a=sqrt(1i*w/D);% [1/m]
TF=1./(1i*w*S).*(   1-exp(-a.*x').*(1+exp(-2*a.*(L-x')))./(1+exp(-2*a.*L))   );% Transfert Function

IR{1}=ifft(.5*[zeros(length(x),1) TF conj(fliplr(TF))],[],2);% Impulse Response function
Diff=inf*ones(length(x),i_max);
equ(ii)=IR{ii}(end,end);

%% loop

for ii=2:i_max
    t=(0:dt:t_max(ii));% new time vec [s]
    f=(1:floor(nb(ii)/2))/t_max(ii);% new frequency vec [Hz]
    w=2*pi.*f;
    a=sqrt(1i*w/D);% [1/m]
    
    TF=1./(1i*w*S).*(   1-exp(-a.*x').*(1+exp(-2*a.*(L-x')))./(1+exp(-2*a.*L))   );% new Transfert Function
    IR{ii}=ifft(.5*[zeros(length(x),1) TF conj(fliplr(TF))],[],2);% new Impulse Response function
    
    Diff(:,ii)=mean(abs(IR{ii-1}-IR{ii}(:,ii-1)),2);
    equ(ii)=IR{ii}(end,end);
end
toc